const config = require('../Utils/config')
const utils = require('../Utils/utils')
const jwt = require('jsonwebtoken')

function authorization(req, res, next) {
    if (req.url == '/users/login' || req.url == '/users/registration' || req.url.startsWith('/image/')) {
        next()
    }
    else {
        const authtoken = req.headers.token
        if (authtoken) {
            try {
                const payload = jwt.verify(authtoken, config.secret)
                req.headers.id = payload.id
                next()
            } catch (error) {
                res.send(utils.createErrorResult('Token is Invalid'))
            }
        }
        else
            res.send(utils.createErrorResult('Token is Missing'))
    }

}

module.exports = authorization