const express = require('express')
const router = express.Router()
const pool = require('../db/mysql')
const utils = require('../Utils/utils')

router.post('/', (req,res) => {
    const {propertyId, total, fromDate, toDate} = req.body
    const statement = `insert into bookings(userId, propertyId, fromDate, toDate, total) values(?,?,?,?,?)`
    pool.query(statement, [req.headers.id, propertyId, fromDate, toDate,total] , (error, data) => {
        res.send(utils.createResult(error, data))
    })
})


router.get('/', (req,res) => {
    const statement = `select * from bookings where id = ?`
    pool.query(statement, req.headers.id, (error, data) => {
        if(data.length != 0){
            res.send(result.createResult(error, data));
        }else{
            res.send(result.createErrorResult('No booking found'));
        }
    })
})

module.exports = router