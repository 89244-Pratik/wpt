const express = require('express')
const db = require('../db/mysql')
const utils = require('../Utils/utils')
const multer = require('multer')

const upload = multer({ dest: 'images' })

const router = express.Router()


router.get('/:image', (req, res) => {
    const imageName = req.params.image;
    const imagePath = path.join(process.cwd(), 'images', imageName);
    console.log(__dirname, imagePath, imageName);
    res.sendFile(imagePath, (err) => {
        if (err) {
            console.error("Image not found:", err);
            res.status(404).send('Image not found');
        }
    });
});

router.post('/', upload.single('icon'), (req, res) => {
    const { title, details } = req.body
    const statement = `insert into category(title, details, image) values(?,?,?)`
    db.execute( statement, [title, details, req.file.filename], (error, categories) => {
        res.send(utils.createResult(error, categories))
    })
})

module.exports = router