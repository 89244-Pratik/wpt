const express = require('express')
const utils = require('../Utils/utils')
const pool = require('../db/mysql')
const multer = require('multer');
const upload = multer({ dest: 'images'});
const router = express.Router()

router.post('/', (req, res) => {
    const {categoryId, title, details, address, contactNo, ownerName, isLakeView, isTV, isAC,  isWifi, isMiniBar, isBreakfast, isParking, guests, bedrooms, beds, bathrooms, rent }=  req.body
    statement = `insert into property(categoryId, title, details, address, contactNo, ownerName, isLakeView, isTV, isAC,  isWifi, isMiniBar, isBreakfast, isParking, guests, bedrooms, beds, bathrooms, rent) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
    pool.query(statement, [categoryId, title, details, address, contactNo, ownerName, isLakeView, isTV, isAC,  isWifi, isMiniBar, isBreakfast, isParking, guests, bedrooms, beds, bathrooms, rent], (error,data) => {
        res.send(utils.createResult(error, data))
    } )
})

router.get('/', (req, res) => {
    const statement = `select id, title, details, rent, profileImage from property`
    pool.query(statement, (error, data) => {
        res.send(utils.createResult(error,data))
        
    })
})

router.get('/details/:id', (req, res) => {
    const id =  req.params.id
    const statement = `select id, title, details, rent, profileImage from property where id = ?`
    pool.query(statement, [id],(error, data) => {
        res.send(utils.createResult(error,data))
        
    })
})

router.put('/:id', upload.single('icon'), (req, res)=>{
    const id = req.params.id;
    console.log(id);
    const {categoryId, title, details, address, contactNo, ownerName, isLakeView, isTV, isAC, isWifi, isMiniBar, isBreakfast, isParking, guests, bedrooms, beds, bathrooms, rent} = req.body
    console.log(req.body);
    const sql = `UPDATE property 
    SET categoryId = ?, 
        title = ?, 
        details = ?, 
        address = ?, 
        contactNo = ?, 
        ownerName = ?, 
        isLakeView = ?, 
        isTV = ?, 
        isAC = ?, 
        isWifi = ?, 
        isMiniBar = ?, 
        isBreakfast = ?, 
        isParking = ?, 
        guests = ?, 
        bedrooms = ?, 
        beds = ?, 
        bathrooms = ?, 
        rent = ?, 
        profileImage = ? 
    WHERE id = ?`;    
    pool.query(sql, [categoryId, title, details, address, contactNo, ownerName, isLakeView, isTV, isAC, isWifi, isMiniBar, isBreakfast, isParking, guests, bedrooms, beds, bathrooms, rent, req.file.filename, id], (error, data)=>{
        res.send(result.createResult(error, data));
    })
})

module.exports = router