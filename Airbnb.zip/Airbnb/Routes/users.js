const express = require('express')
const crypto = require('crypto-js')
const jwt = require('jsonwebtoken')
const utils = require('../Utils/utils')
const pool = require('../db/mysql')
const config = require('../Utils/config')

const router = express.Router()

router.post('/registration', (req, res) => {
    const { firstName, lastName, email, password, phone } = req.body
    const statement = `insert into user(firstName, lastName, email, password, phoneNumber) values(?,?,?,?,?)`
    const encryptedPassword = crypto.SHA256(password).toString()
    pool.execute(statement, [firstName, lastName, email, encryptedPassword, phone], (error, data) => {
        res.send(utils.createResult(error, data))
    })
})

router.post('/login', (req, res) => {
    const { email, password } = req.body
    const encryptedPassword = crypto.SHA256(password).toString()
    const statement = `select id, firstName, lastName, phoneNumber, isDeleted from user where email = ? and password = ?`
    pool.query(statement, [email, encryptedPassword], (error, data) => {
        if (data) {
            if (data.length != 0) {
                const user = data[0]
                if (user.isDeleted) {
                    res.send(utils.createErrorResult('Your account is closed'))
                }
                else {
                    const payload = {
                        id: user.id
                    }
                    const token = jwt.sign(payload, config.secret)
                    const userData = {
                        token: token,
                        name: `${user['firstName']} ${user['lastName']}`
                    }
                    res.send(utils.createSuccessResult(userData))
                }
            }
            else
                res.send(utils.createErrorResult('Invalid email or password'))
        } else
            res.send(utils.createErrorResult(error))
    })
})

router.get('/profile', (req, res) => {
    const statement = 'select firstName, lastName, phoneNumber, email from user where id = ?'
    pool.query(statement, req.headers.id, (error, data) => {
        res.send(utils.createResult(error, data))
    })
})

router.put('/profile', (req, res) => {
    const { firstName, lastName, phone} = req.body
    const statement = 'update user set firstName = ?, lastName = ? , phoneNumber = ? where id = ?'
    pool.query(statement, [ firstName, lastName, phone, req.headers.id], (error, data) => {
        res.send(utils.createResult(error, data))
    })
})

router.put('/activateProfile', (req, res)=>{
    const { email } = req.body;
    const sql = `update user set isDeleted = 0 where email = ?`;

    pool.query(sql, [email], (error, data) => {
        if (error) {
            res.send(result.createErrorResult(error));
        } else if (data.affectedRows != 0) {
            res.send(result.createResult(null, "User Activated Successfully"));
        } else {
            res.send(result.createErrorResult('User not found'));
        }
    });
})

router.delete('/profile', (req, res)=>{
    // const {email} = req.body;
    const sql = `update user set isDeleted = 1 where id = ?`;
    pool.query(sql, [req.headers.id], (error, data)=>{
        if(data){
            if(data.affectedRows != 0){
                res.send(result.createResult(error, data));
            }else{
                res.send(result.createErrorResult('User not found'));
            }
        }else{
            res.send(result.createErrorResult(error));
        }
        
    })
})

module.exports = router